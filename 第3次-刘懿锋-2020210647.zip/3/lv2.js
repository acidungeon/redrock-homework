let arr=[[1,2],3,[4,[5,[6]]],7];
let newarr='';
function even(arr){
    for(let i=0;i<4;i++){
        newarr=newarr+arr[i];
    }
    newarr=newarr.replace(/,/g,'');
}
even(arr);
console.log(newarr);

let arr1=[{id:10,name:'kc'},{id:8,name:'hy'},{id:15,name:'pipi'},{id:2,name:'mama'}];
function compare(p){
    return function (m,n){
        var a=m[p];
        var b=n[p];
        return a-b;
    }
}
arr1.sort(compare('id'));
console.log(arr1);