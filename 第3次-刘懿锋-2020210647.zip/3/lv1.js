var str="can-enter-volunteer-organization";
function change(str) {
    let chgedstr='';
    for(let i=0;i<str.length;i++){
        if(str.charAt(i)=='-') continue;
        chgedstr=chgedstr+str.charAt(i);
    }
    console.log(chgedstr);
}
change(str);

let arr=["myfirstactivity","today activity","yourActivity","activitys"];
let newArr=[];
let count=0;
function findsame(arr){
    for(let i=0;i<4;i++){
        if(arr[i].includes("activity")) {
            newArr[count] = arr[i];
            count++;
        }
    }
}
findsame(arr);
console.log(newArr);