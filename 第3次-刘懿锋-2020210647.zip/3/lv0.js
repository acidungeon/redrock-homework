var a="HelloWorld";
console.log(a);
console.log("HelloWorld");
var arr = ['H','e','l','l','o','W','o','r','l','d'];
var b='';
for(let i=0;i<10;i++){
    b=b+arr[i];
}
console.log(b);
var arr1=[1,5,6,7,'8',10];
var c=0;
for  (let i=0;i<6;i++){
    c=c+Number(arr1[i]);
}
console.log(c);